
// Wait until the DOM is fully loaded before running the script

document.addEventListener('DOMContentLoaded', () => {

    //Get the elements from the DOM that you will work on (box container, new box button, color form, color input).
    const boxContainer = document.getElementById('box-container');
    const newBoxButton = document.getElementById('new-box-button');
    const colorForm = document.getElementById('color-form');
    const colorInput = document.getElementById('color-input');
       
//Create variables to store the box color and counter for the box ID.

    let boxColor = '';
    let boxCounter = 0; 

    //When the form is submitted, get the value from the color input element from Step 2 and set this color to all boxes (to get all boxes, use the class name box). Remember to reset the color input element's value and store the color in the box color variable we created in Step 3.
    colorForm.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent the form from submitting normally
        boxColor = colorInput.value; // Get the color from the input
        colorInput.value = ''; // Reset the input value

        // Set the color for all boxes
        const boxes = document.querySelectorAll('.box');
        boxes.forEach(box => {
            box.style.backgroundColor = boxColor;
        });
    });

// Create a function that adds a new box. In this function, set the box ID as content, the class name, and the background color from the box color variable we created in Step 3. 
    // function addNewBox() {
    //     boxCounter++; // Increment the box counter
    //     const newBox = document.createElement('div'); // Create a new div element
    //     newBox.id = `box-${boxCounter}`; // Set the ID of the new box
    //     newBox.className = 'box'; // Set the class name
    //     newBox.style.backgroundColor = boxColor; // Set the background color
    //     newBox.textContent = `Box ${boxCounter}`; // Set the content of the box

    //     // Append the new box to the box container
    //     boxContainer.appendChild(newBox);
    // }

  // Function to create a new box element
  function createBox() {
    const box = document.createElement('div');
    box.classList.add('box');
    box.style.backgroundColor = currentColor;
    box.textContent = boxIdCounter;
    box.dataset.id = boxIdCounter;
    boxIdCounter++;


});

